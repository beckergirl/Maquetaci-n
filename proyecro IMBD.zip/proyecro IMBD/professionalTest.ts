import {Professional} from "./professional";


let professional1 = new Professional("Owen Wilson", 53, 80, 180, false, "estadounidense", 1, "actor");
let professional2 = new Professional("Cate Blanchett", 53, 70, 174, false, "australiana", 2, "actor");
let professional3 = new Professional("Bill Murray", 72, 87, 188, false, "estadounidense", 0, "actor");
let professional4 = new Professional("Wes Anderson", 53, 75, 180, false, "estadounidense", 0, "director");
let professional5 = new Professional("Jim Jarmusch", 69, 80, 188, false, "estadounidense", 1, "director");


professional1.showAtribs();